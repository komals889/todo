import {REQUEST_TODO,
    SUCCECC_TODO,
    ERROR_TODO,SINGLE_REQUEST_TODO,
    SINGLE_SUCCECC_TODO,
    SINGLE_ERROR_TODO} from '../constant/constant'
export const TodoReducer=(state={reduxTodo:[]},action)=>{
switch (action.type) {
    case REQUEST_TODO:
        return{
            reduxTodo:[]
        }
        break;
    case SUCCECC_TODO:
        return{
            reduxTodo:action.payload
        }
         
    case ERROR_TODO:
        return{
            reduxTodo:action.payload
        }
        

    default:
         return state
}
}
export const SingleTodoReducer=(state={reduxSingleTodo:{}},action)=>{
switch (action.type) {
    case SINGLE_REQUEST_TODO:
        return{
            reduxSingleTodo:{}
        }
    
    case SINGLE_SUCCECC_TODO:
        return{
            reduxSingleTodo:action.payload
        }
         
    case SINGLE_ERROR_TODO:
        return{
            reduxSingleTodo:action.payload
        }
        

    default:
         return state
}
}