 
import React,{useState,useEffect} from 'react'
import {useSelector,useDispatch} from 'react-redux'
import {TodoActionList,SingleTodoActionList} from '../action/todoAction'
export default function Todo() {
    
   const [userId, setuserId] = useState('')
     
     const [todo, settodo] = useState({})
    
    const dispatch=useDispatch()
    const {reduxTodo }=useSelector(state=>state.alldata)
    console.log(reduxTodo);
    
    const {reduxSingleTodo }=useSelector(state=>state.singleTodoData)
    console.log(reduxSingleTodo);
console.log(userId);
useEffect(() => {
    dispatch(TodoActionList())
    dispatch(SingleTodoActionList(todo.id))
}, [dispatch,todo])
    return (
        <div>
            
                <div className="container">
                    <div className="row">
                        <div className="col-lg-10 offset-lg-1">
                            <div className="card-group">
                                <div className="card">
                                    <div className="card-body">
                                    <table className="table">
  <thead>
    <tr className='text-center'>
    <th scope="col">Todo Id</th>

      <th scope="col">Title</th>
 
      <th scope="col">action</th>
      
    </tr>
  </thead>
  <tbody>
   
      {
                                     reduxTodo.map((item,i)=>{
                                         if (i<10) {
                                            return(
                                                <tr key={i}>
                                               
                                                <td>{item.userId}</td>
                                                <td>{item.title}</td>
                                                {/* <td>{item.completed}</td> */}
                                                <td><button index={item.id} className="btn btn-dark" onClick={async(e)=>{    
                                                    await setuserId(e.target.getAttribute('index'))
                                                     
                                                    
                                                     await settodo(item)
                                                     
                                                }}>Click</button></td>
                                                 
                                                </tr>
                                             )
                                         }
                                     })
                                 }
   
    
  </tbody>
</table>
                                    </div>
                                </div>
                                <div className="card">
                                    <div className="card-body">
                                    todo Id :{todo.id} <br />
                                        todo title :{todo.title} <br />
                                        user Id :{reduxSingleTodo.id} <br />
                                        name :{reduxSingleTodo.name} <br />
                                        email :{reduxSingleTodo.email}

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            
        </div>
    )
}
