import axios from 'axios'
import {REQUEST_TODO,
    SUCCECC_TODO,
    ERROR_TODO,SINGLE_REQUEST_TODO,
    SINGLE_SUCCECC_TODO,
    SINGLE_ERROR_TODO} from '../constant/constant'
export const TodoActionList=()=>async(dispatch)=>{
try {
    dispatch({
        type:REQUEST_TODO
    })
    const result=await axios.get("https://jsonplaceholder.typicode.com/todos")
    dispatch({type:SUCCECC_TODO,payload:result.data})
} catch (error) {
    dispatch({type:ERROR_TODO,payload:error})
}
}
export const SingleTodoActionList=(item)=>async(dispatch)=>{
try {
    dispatch({
        type:SINGLE_REQUEST_TODO
    })
    const result1=await axios.get(`https://jsonplaceholder.typicode.com/users/${item}`)
    console.log(result1);
    dispatch({type:SINGLE_SUCCECC_TODO,payload:result1.data})
} catch (error) {
    dispatch({type:SINGLE_ERROR_TODO,payload:error})
}
}