import thunk  from 'redux-thunk'
import {createStore,applyMiddleware,combineReducers} from 'redux'
import {composeWithDevTools} from 'redux-devtools-extension'
import {TodoReducer,SingleTodoReducer} from './reducer/reducerTodo'
const rootReducer=combineReducers({
    alldata:TodoReducer,
    singleTodoData:SingleTodoReducer
})
const store=createStore(rootReducer,{},composeWithDevTools(applyMiddleware(thunk)))
export default store