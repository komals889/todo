import logo from './logo.svg';
import './App.css';
import Todo from './component/Todo';
import {BrowserRouter as Router ,Route} from 'react-router-dom'
function App() {
  return (
   
   <>
    <Todo/>
    <Router>

      <Route path={`/:id` }  ></Route>
    </Router>
   </>
  );
}

export default App;
